<?php

/**
 * @author OnTheGo Systems
 */
interface WPML_WP_Option {
	function get();

	function set( $value );
}